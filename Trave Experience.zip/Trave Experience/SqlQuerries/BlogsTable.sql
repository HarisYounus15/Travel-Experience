Create Table Blogs(
Blog_id int identity(1,1) Primary key,
Blog_content nvarchar(2000),
Blog_DateTime DateTime,
Blog_Image nvarchar(250),
Blog_Location nvarchar(250),
User_id int Foreign Key References Users(User_id)
)