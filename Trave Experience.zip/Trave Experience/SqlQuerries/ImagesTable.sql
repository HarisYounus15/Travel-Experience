Create Table Images(
Id int identity(1,1) Primary Key,
Image nvarchar(50),
Location nvarchar(50),
User_id int foreign key references Users(User_id)
)