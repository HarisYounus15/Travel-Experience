Create Table Users(
User_id int identity(0001,1) primary key,
Username nvarchar(50),
Nickname nvarchar(50),
Password nvarchar(50),
Phoneno nvarchar(14),
Privacy int,
User_Status int
)