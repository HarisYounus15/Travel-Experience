Create Table Comments(
Comment_id int identity(1,1) primary key,
Comment_content nvarchar(2000),
User_id int Foreign key References Users(User_id),
Comment_datetime DateTime
)