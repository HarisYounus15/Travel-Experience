﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Travel_Experience.Models;

namespace Travel_Experience.Controllers
{
    [ApiController]
    [Route("[controller]/")]
    public class TravelExperience : Controller
    {
    [HttpPost("[Action]")]
        public ActionResult GetSignUp(string Username,string FirstName,string LastName, string Password, string Phoneno)
        {
            EncDec encDec = new EncDec();
            var pass = encDec.EncryptString(Password);
            try
            {
                SqlConnection conn = new SqlConnection("Data Source=DESKTOP-SCOF621;Initial Catalog=Travel_Experience;Integrated Security=True");
                SqlCommand cmd = new SqlCommand("INSERT INTO [dbo].[Users]([Username],[FirstName],[Password],[Phoneno],[Privacy],[User_Status],[creation_date],[LastName])VALUES('"+ Username + "','"+FirstName+"','"+ pass + "','"+ Phoneno + "',0,0,'"+DateTime.Now +"','"+LastName+"')",conn);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
                return Ok(new {Message = "Successfully Signup" });
            }catch (Exception ex)
            {
                return Ok(new { Message = "Error" });
            }
        }
        [HttpGet("[Action]")]
        public loginresponse GetUserLoginPass(string Phoneno,string Password)
        {
            loginresponse res = new loginresponse();
            LoginClass lgc = new LoginClass();
            UserLogin lg = new UserLogin();
            try
            {
                res.userlogin = lgc.LoginUser(Phoneno, Password);
                return res;
            }catch (Exception ex)
            {
                res.res_code = "400";
                res.res_msg = ex.Message;
                return res;
            }
        }
        [HttpGet("[Action]")]
        public loginresponse GetUserLoginMail(string Email, string Password)
        {
            loginresponse res = new loginresponse();
            LoginClass lgc = new LoginClass();
            UserLogin lg = new UserLogin();
            try
            {
                res.userlogin = lgc.LoginUserMail(Email, Password);
                if (res.userlogin != null)
                {
                    res.res_code = "200";
                    res.res_msg = "Successfully Login";
                    return res;
                }
                else
                {
                    res.res_code = "400";
                    res.res_msg = "Password Not Right,TryAgain";
                    return res;
                }
            }
            catch (Exception ex)
            {
                res.res_code = "400";
                res.res_msg = ex.Message;
                return res;
            }
        }
        [HttpPut("[Action]")]
        public ActionResult Logout(int userid)
        {
            try
            {
                SqlConnection conn = new SqlConnection("Data Source=DESKTOP-SCOF621;Initial Catalog=Travel_Experience;Integrated Security=True");
                SqlCommand cmd = new SqlCommand("UPDATE [dbo].[Users]SET [User_Status] = 0 WHERE User_id = '" + userid + "'", conn);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
                return Ok(new { ResponseCode = 200 , Message = "Successfully Logout"});
            }
            catch (Exception ex)
            {
                return Ok(new { ResponseCode = 400, Message = "Not Logout" });
            }
        }
        [HttpPost("[Action]")]
        public ActionResult GetSignUpmail(string Username, string FirstName, string LastName, string Password, string Email)
        {
            EncDec encDec = new EncDec();
            var pass = encDec.EncryptString(Password);
            try
            {
                SqlConnection conn = new SqlConnection("Data Source=DESKTOP-SCOF621;Initial Catalog=Travel_Experience;Integrated Security=True");
                SqlCommand cmd = new SqlCommand("INSERT INTO [dbo].[Users]([Username],[FirstName],[Password],[Email],[Privacy],[User_Status],[creation_date],[LastName])VALUES('" + Username + "','" + FirstName + "','" + pass + "','" + Email + "',0,0,'" + DateTime.Now + "','" + LastName + "')", conn);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
                return Ok(new { Message = "Successfully Signup" });
            }
            catch (Exception ex)
            {
                return Ok(new { Message = "Error" });
            }
        }
        [HttpPost("[Action]")]
        public ActionResult BlogPost(string content,string Image,string Location, int Userid)
        {
            try
            {
                SqlConnection conn = new SqlConnection("Data Source=DESKTOP-SCOF621;Initial Catalog=Travel_Experience;Integrated Security=True");
                SqlCommand cmd = new SqlCommand("INSERT INTO[dbo].[Blogs]([Blog_content],[Blog_DateTime],[Blog_Image],[Blog_Location],[User_id])VALUES('"+content+"','"+DateTime.Now+"','"+Image+"','"+Location+"','"+Userid+"')", conn);
                SqlCommand cmd1 = new SqlCommand("INSERT INTO [dbo].[Images]([Image],[Location],[User_id])VALUES('"+Image+"','"+Location+"','"+Userid+"')",conn);
                conn.Open();
                cmd.ExecuteNonQuery();
                cmd1.ExecuteNonQuery();
                conn.Close();
                return Ok(new { Message = "Successfully Signup" });
            }
            catch (Exception ex)
            {
                return Ok(new { Message = "Error" });
            }
        }
        [HttpGet("[Action]")]
        public discoverresponse Discover()
        {
            discoverresponse res = new discoverresponse();
            List<discoverdata> dd_ = new List<discoverdata>();
            try
            {
                SqlConnection conn = new SqlConnection("Data Source=DESKTOP-SCOF621;Initial Catalog=Travel_Experience;Integrated Security=True");
                SqlCommand cmd = new SqlCommand("GetRecentBlogsuser", conn);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                adapter.Fill(ds);
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    discoverdata dd = new discoverdata();
                    dd.blogid = Convert.ToInt32(dr["Blog_id"].ToString());
                    dd.blogcontent = dr["Blog_content"].ToString();
                    dd.blogdate = Convert.ToDateTime(dr["Blog_DateTime"].ToString());
                    dd.blogimage = dr["Blog_Image"].ToString();
                    dd.bloglocation = dr["Blog_Location"].ToString();
                    dd.userid = Convert.ToInt32(dr["User_id"].ToString());
                    dd.username = dr["Username"].ToString();
                    dd_.Add(dd);
                }
                res.discoverd_ = dd_;
                res.res_msg = "Successful";
                res.res_code = "200";
                return res;
            }
            catch (Exception ex)
            {
                res.res_msg = "Error";
                res.res_code = "400";
                return res;
            }
        }
    }
}
