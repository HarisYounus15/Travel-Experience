﻿using System.Data;
using System.Data.SqlClient;
using Travel_Experience.Models;

namespace Travel_Experience
{
    public class LoginClass
    {
        public List<UserLogin> LoginUser(string phoneno,string Password)
        {
            loginresponse res = new loginresponse();
            List<UserLogin> ulg_ = new List<UserLogin>();
            UserLogin ul = new UserLogin();
            EncDec enc = new EncDec();
            try
            {
                SqlConnection conn = new SqlConnection("Data Source=DESKTOP-SCOF621;Initial Catalog=Travel_Experience;Integrated Security=True");
                SqlCommand cmd = new SqlCommand("Select User_id,Phoneno,Email,Password from Users where Phoneno = '" + phoneno+"'",conn);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                adapter.Fill(ds);
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    //UserLogin ul = new UserLogin();
                    ul.Id = Convert.ToInt32(dr["User_id"].ToString());
                    ul.Phonenumber = dr["Phoneno"].ToString();
                    ul.Email = dr["Email"].ToString();
                    ul.password = dr["Password"].ToString();
                    ulg_.Add(ul);
                }
                var pass = enc.DecryptString(ul.password);
                if (pass == Password)
                {
                    SqlCommand cmd1 = new SqlCommand("UPDATE [dbo].[Users]SET [User_Status] = 1 WHERE User_id = '" + ul.Id + "'", conn);
                    conn.Open();
                    cmd1.ExecuteNonQuery();
                    conn.Close();
                    res.res_code = "200";
                    res.res_msg = "Successfully Login";
                    return ulg_;
                }
                else
                {
                    res.res_code = "400";
                    res.res_msg = "Password Not Right,TryAgain";
                    return ulg_;
                }
            }
            catch (Exception ex)
            {
                return ulg_;
            }
        }
        public List<UserLogin> LoginUserMail(string Email, string Password)
        {
            loginresponse res = new loginresponse();
            List<UserLogin> ulg_ = new List<UserLogin>();
            UserLogin ul = new UserLogin();
            EncDec encDec = new EncDec();
            try
            {
                SqlConnection conn = new SqlConnection("Data Source=DESKTOP-SCOF621;Initial Catalog=Travel_Experience;Integrated Security=True");
                SqlCommand cmd = new SqlCommand("Select User_id,Phoneno,Email,Password from Users where Email = '" + Email + "'", conn);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                adapter.Fill(ds);
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    //UserLogin ul = new UserLogin();
                    ul.Id = Convert.ToInt32(dr["User_id"].ToString());
                    ul.Phonenumber = dr["Phoneno"].ToString();
                    ul.Email = dr["Email"].ToString();
                    ul.password = dr["Password"].ToString();
                    ulg_.Add(ul);
                }
                var pass = encDec.DecryptString(ul.password);
                if (pass == Password)
                {
                    SqlCommand cmd1 = new SqlCommand("UPDATE [dbo].[Users]SET [User_Status] = 1 WHERE User_id = '" + ul.Id + "'", conn);
                    conn.Open();
                    cmd1.ExecuteNonQuery();
                    conn.Close();
                    res.res_code = "200";
                    res.res_msg = "Successfully Login";
                    return ulg_;
                }
                else
                {
                    res.res_code = "400";
                    res.res_msg = "Password Not Right,TryAgain";
                    return ulg_;
                }
            }
            catch (Exception ex)
            {
                return ulg_;
            }
        }
    }
}
