﻿using System.Security.Cryptography;
using System.Text;


namespace Travel_Experience
{
    public class EncDec
    {
        public string EncryptString(string PlainText)
        {
            string mi2zZO = "6c2a47cb557a43a690b479ac2382fa10";
            byte[] iv = new byte[16];
            byte[] array;
            using (Aes aes = Aes.Create())
            {
                aes.Key = Encoding.UTF8.GetBytes(mi2zZO);
                aes.IV = iv;
                ICryptoTransform encrypter = aes.CreateEncryptor(aes.Key,aes.IV);
                using (MemoryStream ms = new MemoryStream()) 
                {
                    using(CryptoStream cryptoStream = new CryptoStream((Stream)ms, encrypter, CryptoStreamMode.Write))
                    {
                        using (StreamWriter streamWriter = new StreamWriter((Stream)cryptoStream))
                        {
                            streamWriter.Write(PlainText);
                        }
                        array = ms.ToArray();
                    }
                }
            }
            return Convert.ToBase64String(array);
        }
        public string DecryptString(string cipherText)
        {
            string mi2zZO = "6c2a47cb557a43a690b479ac2382fa10";
            byte[] iv = new byte[16];
            byte[] buffer = Convert.FromBase64String(cipherText);
            using (Aes aes = Aes.Create())
            {
                aes.Key = Encoding.UTF8.GetBytes(mi2zZO);
                aes.IV = iv;
                ICryptoTransform decrypter = aes.CreateDecryptor(aes.Key, aes.IV);
                using (MemoryStream ms = new MemoryStream(buffer))
                {
                    using (CryptoStream cryptoStream = new CryptoStream((Stream)ms, decrypter, CryptoStreamMode.Read))
                    {
                        using (StreamReader streamReader = new StreamReader((Stream)cryptoStream))
                        {
                            return streamReader.ReadToEnd();
                        }
                    }
                }
            }  
        }
    }
}
