﻿namespace Travel_Experience.Models
{
    public class UserLogin
    {
        public int Id { get; set; }
        public string Phonenumber { get; set; }
        public string Email { get; set; }
        public string password { get; set; }
    }
    public class loginresponse
    {
        public string res_code { get; set; }
        public string res_msg { get; set;}

        public List<UserLogin> userlogin { get; set; }
    }
    public class discoverdata
    {
        public int blogid { get; set; }
        public string blogcontent { get; set; }
        public DateTime blogdate { get; set; }
        public string blogimage { get; set; }
        public string bloglocation { get; set; }
        public int userid { get; set; }
        public string username { get; set; } 
    }
    public class discoverresponse
    {
        public string res_code { get; set; }
        public string res_msg { get; set; }
        public List<discoverdata> discoverd_ { get; set;}
    }
}
