﻿using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore;
using Microsoft.VisualBasic;
using System.Data.SqlClient;

namespace Travel_Experience.Models
{
    
   //public class GetConnection()
   // {
        
   // }
}
